package kasus.toko.vapor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VaporApplication {

	public static void main(String[] args) {
		SpringApplication.run(VaporApplication.class, args);
	}

}
