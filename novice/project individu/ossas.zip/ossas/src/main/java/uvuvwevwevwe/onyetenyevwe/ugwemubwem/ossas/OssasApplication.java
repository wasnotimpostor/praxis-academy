package uvuvwevwevwe.onyetenyevwe.ugwemubwem.ossas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OssasApplication {

	public static void main(String[] args) {
		SpringApplication.run(OssasApplication.class, args);
	}

}
