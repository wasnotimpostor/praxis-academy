package uvuvwevwevwe.onyetenyevwe.ugwemubwem.ossas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OssasApplicationTests {

	@Test
	void contextLoads() {
	}

}
