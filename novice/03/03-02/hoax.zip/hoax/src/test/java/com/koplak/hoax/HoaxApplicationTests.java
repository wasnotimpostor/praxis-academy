package com.koplak.hoax;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HoaxApplicationTests {

	@Test
	void contextLoads() {
	}

}
