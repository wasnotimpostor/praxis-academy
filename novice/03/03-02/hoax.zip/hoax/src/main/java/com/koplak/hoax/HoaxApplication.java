package com.koplak.hoax;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HoaxApplication {

	public static void main(String[] args) {
		SpringApplication.run(HoaxApplication.class, args);
	}

}
