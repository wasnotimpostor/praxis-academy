package com.tas.tas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TasApplication {

	public static void main(String[] args) {
		SpringApplication.run(TasApplication.class, args);
	}

}
