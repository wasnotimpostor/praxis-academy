package com.tas.tas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TasApplicationTests {

	@Test
	void contextLoads() {
	}

}
