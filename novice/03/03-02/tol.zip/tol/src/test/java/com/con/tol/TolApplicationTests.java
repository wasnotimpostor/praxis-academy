package com.con.tol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TolApplicationTests {

	@Test
	void contextLoads() {
	}

}
