package com.co.ba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaApplicationTests {

	@Test
	void contextLoads() {
	}

}
