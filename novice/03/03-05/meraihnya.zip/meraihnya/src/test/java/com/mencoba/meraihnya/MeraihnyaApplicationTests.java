package com.mencoba.meraihnya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeraihnyaApplicationTests {

	@Test
	void contextLoads() {
	}

}
