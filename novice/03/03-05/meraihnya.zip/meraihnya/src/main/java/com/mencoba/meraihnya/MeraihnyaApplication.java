package com.mencoba.meraihnya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeraihnyaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeraihnyaApplication.class, args);
	}

}
