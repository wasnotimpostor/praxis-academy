package com.kepo.kemplo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KemploApplicationTests {

	@Test
	void contextLoads() {
	}

}
