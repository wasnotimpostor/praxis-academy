package contoh.praxis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PraxisApplicationTests {

	@Test
	void contextLoads() {
	}

}
