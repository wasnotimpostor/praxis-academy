package contoh.praxis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PraxisApplication {

	public static void main(String[] args) {
		SpringApplication.run(PraxisApplication.class, args);
	}

}
