package com.praxis.kepo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KepoApplication {

	public static void main(String[] args) {
		SpringApplication.run(KepoApplication.class, args);
	}

}
