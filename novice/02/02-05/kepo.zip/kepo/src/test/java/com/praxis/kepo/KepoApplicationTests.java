package com.praxis.kepo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KepoApplicationTests {

	@Test
	void contextLoads() {
	}

}
