package com.sample.kampus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KampusApplicationTests {

	@Test
	void contextLoads() {
	}

}
