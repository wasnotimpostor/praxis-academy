package com.praxis.connectdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConnectdbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConnectdbApplication.class, args);
	}

}
