package com.praxis.connectdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConnectdbApplicationTests {

	@Test
	void contextLoads() {
	}

}
